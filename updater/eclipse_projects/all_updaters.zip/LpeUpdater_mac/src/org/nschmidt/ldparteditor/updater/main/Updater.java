/* MIT - License

Copyright (c) 2012 - this year, Nils Schmidt

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */
package org.nschmidt.ldparteditor.updater.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

import javax.swing.JOptionPane;


/**
 * @author nils
 *
 */
public class Updater {

    private final static String OS = "mac_x86"; //$NON-NLS-1$


    /**
     * Program entry point
     *
     * @param args
     *            startup arguments
     */
    public static void main(String[] args) {
        try {
            String decodedPath = URLDecoder.decode(ClassLoader.getSystemClassLoader().getResource(".").getPath(), "UTF-8"); //$NON-NLS-1$ //$NON-NLS-2$
            String targetFileName = decodedPath.substring(0, decodedPath.lastIndexOf(File.separator) + 1) + "update.txt"; //$NON-NLS-1$
            String targetZipFileName = decodedPath.substring(0, decodedPath.lastIndexOf(File.separator) + 1) + "update.zip"; //$NON-NLS-1$

            File upd = new File(targetFileName);
            if (upd.exists()) {
                if (!upd.delete()) {
                    return;
                }
            }
            upd = new File(targetZipFileName);
            if (upd.exists()) {
                if (!upd.delete()) {
                    return;
                }
            }
            {
                ReadableByteChannel in = null;
                FileChannel out = null;
                try {
                    System.out.println("Downloading source path info..."); //$NON-NLS-1$
                    in = Channels.newChannel(new URL("https://github.com/nilsschmidt1337/ldparteditor/blob/master/updater/" + OS + ".txt?raw=true").openStream()); //$NON-NLS-1$ //$NON-NLS-2$
                    out= new FileOutputStream(targetFileName).getChannel();

                    out.transferFrom(in, 0, Long.MAX_VALUE);

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    return;
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                } finally {
                    try {
                        in.close();
                    } catch (Exception consumed) {}
                    try {
                        out.close();
                    } catch (Exception consumed) {}
                }
            }
            upd = new File(targetFileName);
            if (upd.exists()) {

                String url = null;

                BufferedReader br = null;
                try {
                    br = new BufferedReader(new FileReader(targetFileName));
                    url = br.readLine();
                    System.out.println("Fetching data from: " + url); //$NON-NLS-1$
                } catch (FileNotFoundException e) {
                    return;
                } catch (IOException e) {
                    return;
                } finally {
                    if (br != null) {
                        try {
                            br.close();
                        } catch (IOException e) {}
                    } else {
                        return;
                    }
                }

                {
                    ReadableByteChannel in = null;
                    FileChannel out = null;
                    try {
                        in = Channels.newChannel(new URL(url).openStream());
                        out= new FileOutputStream(targetZipFileName).getChannel();

                        out.transferFrom(in, 0, Long.MAX_VALUE);

                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    } finally {
                        try {
                            in.close();
                        } catch (Exception consumed) {}
                        try {
                            out.close();
                        } catch (Exception consumed) {}
                    }
                }
                upd = new File(targetZipFileName);
                if (upd.exists()) {
                    try {
                        System.out.println("Extracting..."); //$NON-NLS-1$
                        ZipInputStream zis = new ZipInputStream(new FileInputStream(upd));
                        ZipEntry ze = zis.getNextEntry();
                        while(ze!=null){
                            String entryName = ze.getName();
                            if (ze.isDirectory()) {
                                File f = new File(entryName);
                                f.mkdirs();
                            }else {
                                File f = new File(entryName);
                                FileOutputStream fos = new FileOutputStream(f);
                                int len;
                                byte buffer[] = new byte[1024];
                                while ((len = zis.read(buffer)) > 0) {
                                    fos.write(buffer, 0, len);
                                }
                                fos.close();
                            }
                            ze = zis.getNextEntry();
                        }
                        zis.closeEntry();
                        zis.close();
                    } catch (ZipException e) {
                        e.printStackTrace();
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                    if (!upd.delete()) {
                        return;
                    }
                    upd = new File(targetFileName);
                    if (!upd.delete()) {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                return;
            }
        } catch (SecurityException se) {
            se.printStackTrace();
            return;
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
            return;
        }
        {
            JOptionPane.showMessageDialog(null, "EN: The update was successful!\nGER: Die Aktualisierung war erfolgreich!", "LD Part Editor", JOptionPane.INFORMATION_MESSAGE); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }
}
