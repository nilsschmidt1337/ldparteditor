package org.nschmidt.ldparteditor.updater.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

import javax.swing.JOptionPane;


/**
 * @author nils
 *
 */
public class Updater {

    private final static String OS = "win32_x64"; //$NON-NLS-1$

    /**
     * Program entry point
     *
     * @param args
     *            startup arguments
     */
    public static void main(String[] args) {
        try {
            String decodedPath = URLDecoder.decode(ClassLoader.getSystemClassLoader().getResource(".").getPath(), "UTF-8"); //$NON-NLS-1$ //$NON-NLS-2$
            String targetZipFileName = decodedPath.substring(0, decodedPath.lastIndexOf(File.separator) + 1) + "update.zip"; //$NON-NLS-1$

            File upd = new File(targetZipFileName);
            if (upd.exists()) {
                if (!upd.delete()) {
                    return;
                }
            }
            String source = null;
            {
                BufferedReader in = null;

                try {
                    System.out.println("Downloading source path info..."); //$NON-NLS-1$
                    in = new BufferedReader(new InputStreamReader(new URL("https://github.com/nilsschmidt1337/ldparteditor/blob/master/updater/" + OS + ".txt?raw=true").openStream())); //$NON-NLS-1$ //$NON-NLS-2$
                    source = in.readLine();
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    return;
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                } finally {
                    try {
                        in.close();
                    } catch (Exception consumed) {}
                }
            }
            if (source != null) {

                String url = source;
                System.out.println("Fetching data from: " + url); //$NON-NLS-1$

                {
                    ReadableByteChannel in = null;
                    FileChannel out = null;
                    try {
                        in = Channels.newChannel(new URL(url).openStream());
                        out= new FileOutputStream(targetZipFileName).getChannel();

                        out.transferFrom(in, 0, Long.MAX_VALUE);

                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    } finally {
                        try {
                            in.close();
                        } catch (Exception consumed) {}
                        try {
                            out.close();
                        } catch (Exception consumed) {}
                    }
                }
                upd = new File(targetZipFileName);
                if (upd.exists()) {
                    try {
                        System.out.println("Extracting..."); //$NON-NLS-1$
                        ZipInputStream zis = new ZipInputStream(new FileInputStream(upd));
                        ZipEntry ze = zis.getNextEntry();
                        while(ze!=null){
                            String entryName = ze.getName();
                            if (ze.isDirectory()) {
                                File f = new File(entryName);
                                f.mkdirs();
                            }else {
                                File f = new File(entryName);
                                FileOutputStream fos = new FileOutputStream(f);
                                int len;
                                byte buffer[] = new byte[1024];
                                while ((len = zis.read(buffer)) > 0) {
                                    fos.write(buffer, 0, len);
                                }
                                fos.close();
                            }
                            ze = zis.getNextEntry();
                        }
                        zis.closeEntry();
                        zis.close();
                    } catch (ZipException e) {
                        e.printStackTrace();
                        return;
                    } catch (IOException e) {
                        e.printStackTrace();
                        return;
                    }
                    if (!upd.delete()) {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                return;
            }
        } catch (SecurityException se) {
            se.printStackTrace();
            return;
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
            return;
        }
        JOptionPane.showMessageDialog(null, "EN: The update was successful!\nGER: Die Aktualisierung war erfolgreich!", "LD Part Editor", JOptionPane.INFORMATION_MESSAGE); //$NON-NLS-1$ //$NON-NLS-2$
    }
}