/* MIT - License

Copyright (c) 2012 - this year, Nils Schmidt

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE
FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. */
package org.nschmidt.ldparteditor.updater.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.channels.Channels;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;

import javax.swing.JOptionPane;


/**
 * @author nils
 *
 */
public class Updater {




    /**
     * Program entry point
     *
     * @param args
     *            startup arguments
     */
    public static void main(String[] args) {
        try {
            String decodedPath = URLDecoder.decode(ClassLoader.getSystemClassLoader().getResource(".").getPath(), "UTF-8"); //$NON-NLS-1$ //$NON-NLS-2$
            String targetFileName = decodedPath.substring(0, decodedPath.lastIndexOf(File.separator) + 1) + "update.zip"; //$NON-NLS-1$
            File upd = new File(targetFileName);
            if (upd.exists()) {
                if (!upd.delete()) {
                    return;
                }
            }
            ReadableByteChannel in = null;
            FileChannel out = null;
            try {
                in = Channels.newChannel(new URL("http://downloads.sourceforge.net/project/partcreator/stable/Windows_64bit/update.zip?r=&ts=&use_mirror=master").openStream()); //$NON-NLS-1$
                out= new FileOutputStream(targetFileName).getChannel();

                out.transferFrom(in, 0, Long.MAX_VALUE);

            } catch (MalformedURLException e) {
                e.printStackTrace();
                return;
            } catch (IOException e) {
                e.printStackTrace();
                return;
            } finally {
                try {
                    in.close();
                } catch (Exception consumed) {}
                try {
                    out.close();
                } catch (Exception consumed) {}
            }
            upd = new File(targetFileName);
            if (upd.exists()) {
                try {
                    ZipInputStream zis = new ZipInputStream(new FileInputStream(upd));
                    ZipEntry ze = zis.getNextEntry();
                    while(ze!=null){
                        String entryName = ze.getName();
                        if (ze.isDirectory()) {
                            File f = new File(entryName);
                            f.mkdirs();
                        }else {
                            File f = new File(entryName);
                            FileOutputStream fos = new FileOutputStream(f);
                            int len;
                            byte buffer[] = new byte[1024];
                            while ((len = zis.read(buffer)) > 0) {
                                fos.write(buffer, 0, len);
                            }
                            fos.close();
                        }
                        ze = zis.getNextEntry();
                    }
                    zis.closeEntry();
                    zis.close();
                } catch (ZipException e) {
                    e.printStackTrace();
                    return;
                } catch (IOException e) {
                    e.printStackTrace();
                    return;
                }
                if (!upd.delete()) {
                    return;
                }
            } else {
                return;
            }
        } catch (SecurityException se) {
            se.printStackTrace();
            return;
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
            return;
        }
        {
            JOptionPane.showMessageDialog(null, "EN: The update was successful!\nGER: Die Aktualisierung war erfolgreich!", "LD Part Editor", JOptionPane.INFORMATION_MESSAGE); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }
}
